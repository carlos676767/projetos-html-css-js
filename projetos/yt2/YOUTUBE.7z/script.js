function alerta(){
    alert("erro, voce esta sem microfone")
    window.prompt("voce colocou seu microfone?")
}